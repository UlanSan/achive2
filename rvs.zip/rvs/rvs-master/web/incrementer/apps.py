from django.apps import AppConfig


class IncrementerConfig(AppConfig):
    name = 'incrementer'
